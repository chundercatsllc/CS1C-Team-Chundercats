var class_ellipse =
[
    [ "Ellipse", "class_ellipse.html#af31f4f441414671f76c60b03516eb5d6", null ],
    [ "~Ellipse", "class_ellipse.html#af7b546b29a2f8ce3494f9d02143a621c", null ],
    [ "area", "class_ellipse.html#abdcc9bf2ca75e53000eecd7fce16d1ea", null ],
    [ "draw", "class_ellipse.html#ae83718bf96925955fa48c14a4217c73c", null ],
    [ "getHeight", "class_ellipse.html#acd5005522d00f0e3235a2d4d931c0e39", null ],
    [ "getLocation", "class_ellipse.html#a39951db608b73cb66b250e2811680faf", null ],
    [ "getWidth", "class_ellipse.html#a79b45a55a6dc182866659c00535bba5e", null ],
    [ "move", "class_ellipse.html#a1929dda25f9dc816835e05c57937d34a", null ],
    [ "perimeter", "class_ellipse.html#abb2c4bca7f3c88c16a81f6ecb9d93e5c", null ],
    [ "setDimensions", "class_ellipse.html#af3e06272b3d22f3249ff04288df1f6dd", null ],
    [ "setLocation", "class_ellipse.html#aa24fd99eedbfc4b45c2b2c2a11cd5759", null ],
    [ "setLocation", "class_ellipse.html#a4af4a28871b606d434fc62aee9f82c24", null ]
];