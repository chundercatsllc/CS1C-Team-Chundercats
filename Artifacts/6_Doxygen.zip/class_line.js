var class_line =
[
    [ "Line", "class_line.html#abfce044bd32535d51e49ed00d401aee0", null ],
    [ "~Line", "class_line.html#af18447238883377a0071d2276a4ac0a5", null ],
    [ "area", "class_line.html#a5989f939ab0025b09d0da1aee6421122", null ],
    [ "draw", "class_line.html#a3b191dfa5dd12e9be51ed225607696e5", null ],
    [ "move", "class_line.html#abbae60ea00ae0759ede7b43b788c2028", null ],
    [ "perimeter", "class_line.html#ad1fa30c56b29c961f26885edcb2f8109", null ],
    [ "setPoints", "class_line.html#a1ff33e610802339eca8d9b421b32dd60", null ]
];