var class_text =
[
    [ "Text", "class_text.html#ae56225ea39562e2cc7b401b017d175b5", null ],
    [ "~Text", "class_text.html#a4e7641708dfbf9c6bbbd41e897e9139c", null ],
    [ "area", "class_text.html#ab9d0f9643d33550828eb23e3a5436036", null ],
    [ "draw", "class_text.html#a2401b42a363c41b8be6219eb1b14d08f", null ],
    [ "getFlag", "class_text.html#abc42bd7502e8441a041f50695880bc8c", null ],
    [ "getFont", "class_text.html#aceef51d21bc54b84d040db42e425acd1", null ],
    [ "getText", "class_text.html#a0315e3d6a80d496496838330e018e7e8", null ],
    [ "move", "class_text.html#af684963e401cbbddab1c3b5032e733bc", null ],
    [ "perimeter", "class_text.html#aba53a89dd7a2fae148a403a8c4d2e9b1", null ],
    [ "setBoxHeight", "class_text.html#a7ecc194467d74cecff8b0027cb3534f5", null ],
    [ "setBoxWidth", "class_text.html#a83117073736a3c882180b46e9af22135", null ],
    [ "setDimensions", "class_text.html#a4dfaf7c6694970dff0ff50f2205802da", null ],
    [ "setFlag", "class_text.html#af96574d035d39aaec84660de28dd9116", null ],
    [ "setLocation", "class_text.html#a3d48c0d2794e52b4fa525d5d7e2ddf2f", null ],
    [ "setLocation", "class_text.html#a86d801852c8fe7d736915f2386b1134f", null ],
    [ "setText", "class_text.html#a9e7c48bfb75a9c2ddf246dc0a7add7e4", null ]
];