var class_shape =
[
    [ "ShapeType", "class_shape.html#a4cb9bc6c74b4184257003c83a8d8d39e", [
      [ "null", "class_shape.html#a4cb9bc6c74b4184257003c83a8d8d39ea37a6259cc0c1dae299a7866489dff0bd", null ],
      [ "Line", "class_shape.html#a4cb9bc6c74b4184257003c83a8d8d39ea4803e6b9e63dabf04de980788d6a13c4", null ],
      [ "Polyline", "class_shape.html#a4cb9bc6c74b4184257003c83a8d8d39eaf8fb02b84176d0b0f0007abfd9264fb9", null ],
      [ "Polygon", "class_shape.html#a4cb9bc6c74b4184257003c83a8d8d39ea4c0a11247d92f73fb84baa51e37a3263", null ],
      [ "Rectangle", "class_shape.html#a4cb9bc6c74b4184257003c83a8d8d39eace9291906a4c3b042650b70d7f3b152e", null ],
      [ "Ellipse", "class_shape.html#a4cb9bc6c74b4184257003c83a8d8d39ea119518c2134c46108179369f0ce81fa2", null ],
      [ "Text", "class_shape.html#a4cb9bc6c74b4184257003c83a8d8d39ea9dffbf69ffba8bc38bc4e01abf4b1675", null ]
    ] ],
    [ "Shape", "class_shape.html#a68b33425752aa52e626fa90bde66c4ef", null ],
    [ "~Shape", "class_shape.html#ac3b9fc48965274893f25b18aa14ba665", null ],
    [ "area", "class_shape.html#aa3072fde001d5174f78fcc484c11870c", null ],
    [ "draw", "class_shape.html#ad2ab549a1b0cc0e23af8be1fd1b61a1b", null ],
    [ "getBrush", "class_shape.html#af20b7e861223131bc521b1bbd1c960b8", null ],
    [ "getID", "class_shape.html#a75389ae79e394b5bd136888c67ae94ed", null ],
    [ "getPen", "class_shape.html#af4543da5152297b5eaf0d160ecc977e1", null ],
    [ "getQPainter", "class_shape.html#a8c73120ac285b4131e2075b15207feac", null ],
    [ "getShape", "class_shape.html#a0526a3459d426e12f5e754a628bb4bbe", null ],
    [ "move", "class_shape.html#a937ef09c5e1c5c640fdef7caf62ba8f2", null ],
    [ "perimeter", "class_shape.html#afb064edd78952da66801619338e8c5a3", null ],
    [ "setBrush", "class_shape.html#a2ec2004e468730778d28ec731c3ae099", null ],
    [ "setBrush", "class_shape.html#a9902d301bf27dae6ffc4a81ff566bfa3", null ],
    [ "setDefaultStyle", "class_shape.html#a4530667938d412921f21b39f23d98399", null ],
    [ "setID", "class_shape.html#ab5f7a5775837a4c4d4187d901990c1c2", null ],
    [ "setPen", "class_shape.html#a83027240b45ec72e7d25c1e93044fa50", null ],
    [ "setPen", "class_shape.html#a2fecea077c3da057aaab21b8ccd31ac2", null ],
    [ "setPen", "class_shape.html#a3cabd869e27b2662bf75b980d1795f32", null ],
    [ "setShape", "class_shape.html#ad6e31e2ee0a6270ec8a1d08ea066ee66", null ],
    [ "brush", "class_shape.html#aa67647c3a5d39d1e3f63a241208e59f2", null ],
    [ "painter", "class_shape.html#a761a117dfc4b157944e512b8a4c89fde", null ],
    [ "pen", "class_shape.html#a75d192b68eddd2622bdea8a4ac1058d1", null ]
];