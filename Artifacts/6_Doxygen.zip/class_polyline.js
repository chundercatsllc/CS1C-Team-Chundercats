var class_polyline =
[
    [ "Polyline", "class_polyline.html#a2587221692617dcbd2d8cf4e82d1857a", null ],
    [ "~Polyline", "class_polyline.html#af77a79ed0a14a8334cfd92cd17063fec", null ],
    [ "addNumPoints", "class_polyline.html#a947a2b96443f0759b047b27a805903c4", null ],
    [ "addPoint", "class_polyline.html#a0f72a85f41fcdbcf32f9029e7c717ff3", null ],
    [ "area", "class_polyline.html#a94f6c78fc78eaf2efd0d5221fd7b44dc", null ],
    [ "draw", "class_polyline.html#a852420931a45f831deaff590c40b150c", null ],
    [ "getNumPoints", "class_polyline.html#a80b8c56a38d4dcf70ac9f3bd314aec2b", null ],
    [ "getPoints", "class_polyline.html#a4583e6c29cb39db29fdae796f7968632", null ],
    [ "move", "class_polyline.html#a33cd81f76e084f77ffcd9304c879354e", null ],
    [ "perimeter", "class_polyline.html#a1c9bb62b882f1c97d6aaa40755dc8746", null ]
];