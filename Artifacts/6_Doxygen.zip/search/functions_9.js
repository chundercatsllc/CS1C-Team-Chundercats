var searchData=
[
  ['setall',['setAll',['../class_rectangle.html#a583a73ee34b4ce7b60459922dbb2094d',1,'Rectangle']]],
  ['setboxheight',['setBoxHeight',['../class_text.html#a7ecc194467d74cecff8b0027cb3534f5',1,'Text']]],
  ['setboxwidth',['setBoxWidth',['../class_text.html#a83117073736a3c882180b46e9af22135',1,'Text']]],
  ['setbrush',['setBrush',['../class_shape.html#a2ec2004e468730778d28ec731c3ae099',1,'Shape::setBrush(Qt::GlobalColor, Qt::BrushStyle)'],['../class_shape.html#a9902d301bf27dae6ffc4a81ff566bfa3',1,'Shape::setBrush(QBrush brsh)']]],
  ['setdefaultstyle',['setDefaultStyle',['../class_shape.html#a4530667938d412921f21b39f23d98399',1,'Shape']]],
  ['setdimensions',['setDimensions',['../class_text.html#a4dfaf7c6694970dff0ff50f2205802da',1,'Text::setDimensions()'],['../class_rectangle.html#a10a5a88119f55914c1d9d68a7678d457',1,'Rectangle::setDimensions()'],['../class_ellipse.html#af3e06272b3d22f3249ff04288df1f6dd',1,'Ellipse::setDimensions()']]],
  ['setflag',['setFlag',['../class_text.html#af96574d035d39aaec84660de28dd9116',1,'Text']]],
  ['setid',['setID',['../class_shape.html#ab5f7a5775837a4c4d4187d901990c1c2',1,'Shape']]],
  ['setlocation',['setLocation',['../class_text.html#a3d48c0d2794e52b4fa525d5d7e2ddf2f',1,'Text::setLocation(int x, int y)'],['../class_text.html#a86d801852c8fe7d736915f2386b1134f',1,'Text::setLocation(QPoint pt)'],['../class_rectangle.html#a6d2dd7280e01d1d3a044a852d0b42619',1,'Rectangle::setLocation(int x, int y)'],['../class_rectangle.html#a3e38c916a6685543e8a2196f25d6ebdc',1,'Rectangle::setLocation(QPoint pt)'],['../class_ellipse.html#aa24fd99eedbfc4b45c2b2c2a11cd5759',1,'Ellipse::setLocation(int x, int y)'],['../class_ellipse.html#a4af4a28871b606d434fc62aee9f82c24',1,'Ellipse::setLocation(QPoint pt)']]],
  ['setnumvertices',['setNumVertices',['../class_polygon.html#a0ab9c9ec47b65946a9789a38581879ff',1,'Polygon']]],
  ['setpen',['setPen',['../class_shape.html#a83027240b45ec72e7d25c1e93044fa50',1,'Shape::setPen(Qt::GlobalColor)'],['../class_shape.html#a2fecea077c3da057aaab21b8ccd31ac2',1,'Shape::setPen(Qt::GlobalColor, int width, Qt::PenStyle, Qt::PenCapStyle, Qt::PenJoinStyle)'],['../class_shape.html#a3cabd869e27b2662bf75b980d1795f32',1,'Shape::setPen(QPen pn)']]],
  ['setpoints',['setPoints',['../class_line.html#a1ff33e610802339eca8d9b421b32dd60',1,'Line']]],
  ['setshape',['setShape',['../class_shape.html#ad6e31e2ee0a6270ec8a1d08ea066ee66',1,'Shape']]],
  ['setshapenonsense',['setShapeNonsense',['../class_main_window.html#a338d020f4155f744e811c2450717c584',1,'MainWindow']]],
  ['settext',['setText',['../class_text.html#a9e7c48bfb75a9c2ddf246dc0a7add7e4',1,'Text']]],
  ['shape',['Shape',['../class_shape.html#a68b33425752aa52e626fa90bde66c4ef',1,'Shape']]],
  ['sizehint',['sizeHint',['../class_render_area.html#ac0b3e7195c5ba16eaa6590168db0f0cf',1,'RenderArea']]]
];
