var searchData=
[
  ['painter',['painter',['../class_shape.html#a761a117dfc4b157944e512b8a4c89fde',1,'Shape']]],
  ['pen',['pen',['../class_shape.html#a75d192b68eddd2622bdea8a4ac1058d1',1,'Shape']]]
];
