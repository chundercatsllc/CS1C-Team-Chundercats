var searchData=
[
  ['brush',['brush',['../class_shape.html#aa67647c3a5d39d1e3f63a241208e59f2',1,'Shape']]]
];
