var searchData=
[
  ['text',['Text',['../class_text.html',1,'Text'],['../class_text.html#ae56225ea39562e2cc7b401b017d175b5',1,'Text::Text()']]]
];
