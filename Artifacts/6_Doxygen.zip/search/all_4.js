var searchData=
[
  ['ellipse',['Ellipse',['../class_ellipse.html',1,'Ellipse'],['../class_ellipse.html#af31f4f441414671f76c60b03516eb5d6',1,'Ellipse::Ellipse()']]]
];
