var hierarchy =
[
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QPainter", null, [
      [ "Shape", "class_shape.html", [
        [ "Ellipse", "class_ellipse.html", null ],
        [ "Line", "class_line.html", null ],
        [ "Polygon", "class_polygon.html", null ],
        [ "Polyline", "class_polyline.html", null ],
        [ "Rectangle", "class_rectangle.html", null ],
        [ "Text", "class_text.html", null ]
      ] ]
    ] ],
    [ "QWidget", null, [
      [ "RenderArea", "class_render_area.html", null ]
    ] ]
];