var annotated_dup =
[
    [ "Ellipse", "class_ellipse.html", "class_ellipse" ],
    [ "Line", "class_line.html", "class_line" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "Polygon", "class_polygon.html", "class_polygon" ],
    [ "Polyline", "class_polyline.html", "class_polyline" ],
    [ "Rectangle", "class_rectangle.html", "class_rectangle" ],
    [ "RenderArea", "class_render_area.html", "class_render_area" ],
    [ "Shape", "class_shape.html", "class_shape" ],
    [ "Text", "class_text.html", "class_text" ]
];